Directory structure:

Directory